"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _https = _interopRequireDefault(require("https"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const agent = new _https.default.Agent({
  rejectUnauthorized: false
});
var _default = agent;
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlcnZlcl9jbGllbnQudHMiXSwibmFtZXMiOlsiYWdlbnQiLCJodHRwcyIsIkFnZW50IiwicmVqZWN0VW5hdXRob3JpemVkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7Ozs7QUFFQSxNQUFNQSxLQUFLLEdBQUcsSUFBSUMsZUFBTUMsS0FBVixDQUFnQjtBQUM1QkMsRUFBQUEsa0JBQWtCLEVBQUU7QUFEUSxDQUFoQixDQUFkO2VBSWVILEsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgaHR0cHMgZnJvbSAnaHR0cHMnO1xuXG5jb25zdCBhZ2VudCA9IG5ldyBodHRwcy5BZ2VudCh7ICBcbiAgcmVqZWN0VW5hdXRob3JpemVkOiBmYWxzZVxufSk7XG5cbmV4cG9ydCBkZWZhdWx0IGFnZW50OyJdfQ==