"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.plugin = plugin;
Object.defineProperty(exports, "KibanaPrometheusExporterPluginSetup", {
  enumerable: true,
  get: function () {
    return _types.KibanaPrometheusExporterPluginSetup;
  }
});
Object.defineProperty(exports, "KibanaPrometheusExporterPluginStart", {
  enumerable: true,
  get: function () {
    return _types.KibanaPrometheusExporterPluginStart;
  }
});

var _plugin = require("./plugin");

var _types = require("./types");

//  This exports static code and TypeScript types,
//  as well as, Kibana Platform `plugin()` initializer.
function plugin(initializerContext) {
  return new _plugin.KibanaPrometheusExporterPlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbInBsdWdpbiIsImluaXRpYWxpemVyQ29udGV4dCIsIktpYmFuYVByb21ldGhldXNFeHBvcnRlclBsdWdpbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNBOztBQVNBOztBQVBBO0FBQ0E7QUFFTyxTQUFTQSxNQUFULENBQWdCQyxrQkFBaEIsRUFBOEQ7QUFDbkUsU0FBTyxJQUFJQyxzQ0FBSixDQUFtQ0Qsa0JBQW5DLENBQVA7QUFDRCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBsdWdpbkluaXRpYWxpemVyQ29udGV4dCB9IGZyb20gJy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyBLaWJhbmFQcm9tZXRoZXVzRXhwb3J0ZXJQbHVnaW4gfSBmcm9tICcuL3BsdWdpbic7XG5cbi8vICBUaGlzIGV4cG9ydHMgc3RhdGljIGNvZGUgYW5kIFR5cGVTY3JpcHQgdHlwZXMsXG4vLyAgYXMgd2VsbCBhcywgS2liYW5hIFBsYXRmb3JtIGBwbHVnaW4oKWAgaW5pdGlhbGl6ZXIuXG5cbmV4cG9ydCBmdW5jdGlvbiBwbHVnaW4oaW5pdGlhbGl6ZXJDb250ZXh0OiBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQpIHtcbiAgcmV0dXJuIG5ldyBLaWJhbmFQcm9tZXRoZXVzRXhwb3J0ZXJQbHVnaW4oaW5pdGlhbGl6ZXJDb250ZXh0KTtcbn1cblxuZXhwb3J0IHsgS2liYW5hUHJvbWV0aGV1c0V4cG9ydGVyUGx1Z2luU2V0dXAsIEtpYmFuYVByb21ldGhldXNFeHBvcnRlclBsdWdpblN0YXJ0IH0gZnJvbSAnLi90eXBlcyc7XG4iXX0=