"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defineRoutes = defineRoutes;

var _formatter = _interopRequireDefault(require("../../common/formatter"));

var _axios = _interopRequireDefault(require("axios"));

var _server_client = _interopRequireDefault(require("../helpers/server_client"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function defineRoutes(router) {
  router.get({
    path: '/_prometheus/metrics',
    validate: false
  }, async (context, request, response) => {
    var _request$url$host;

    let reqHeaders = {};
    let reqProto = request.url.protocol || 'http:';
    let reqHost = ((_request$url$host = request.url.host) === null || _request$url$host === void 0 ? void 0 : _request$url$host.replace(/:\d+/, '')) || '127.0.0.1';
    let reqPort = request.url.port || 5601;
    let reqUrl = `${reqProto}//${reqHost}:${reqPort}/api/status`;

    if (request.headers !== undefined && request.headers.authorization !== undefined) {
      reqHeaders = {
        'Authorization': request.headers.authorization
      };
    }

    const kibanaInternalStatus = await _axios.default.get(reqUrl, {
      headers: reqHeaders,
      httpsAgent: _server_client.default
    });
    const prometheusStats = (0, _formatter.default)(kibanaInternalStatus.data);
    return response.ok({
      headers: {
        'Content-Type': 'text/plain'
      },
      body: prometheusStats
    });
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbImRlZmluZVJvdXRlcyIsInJvdXRlciIsImdldCIsInBhdGgiLCJ2YWxpZGF0ZSIsImNvbnRleHQiLCJyZXF1ZXN0IiwicmVzcG9uc2UiLCJyZXFIZWFkZXJzIiwicmVxUHJvdG8iLCJ1cmwiLCJwcm90b2NvbCIsInJlcUhvc3QiLCJob3N0IiwicmVwbGFjZSIsInJlcVBvcnQiLCJwb3J0IiwicmVxVXJsIiwiaGVhZGVycyIsInVuZGVmaW5lZCIsImF1dGhvcml6YXRpb24iLCJraWJhbmFJbnRlcm5hbFN0YXR1cyIsImF4aW9zIiwiaHR0cHNBZ2VudCIsImFnZW50IiwicHJvbWV0aGV1c1N0YXRzIiwiZGF0YSIsIm9rIiwiYm9keSJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUNBOztBQUNBOztBQUNBOzs7O0FBRU8sU0FBU0EsWUFBVCxDQUFzQkMsTUFBdEIsRUFBdUM7QUFDNUNBLEVBQUFBLE1BQU0sQ0FBQ0MsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRSxzQkFEUjtBQUVFQyxJQUFBQSxRQUFRLEVBQUU7QUFGWixHQURGLEVBS0UsT0FBT0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQUE7O0FBQ3BDLFFBQUlDLFVBQVUsR0FBRyxFQUFqQjtBQUNBLFFBQUlDLFFBQVEsR0FBR0gsT0FBTyxDQUFDSSxHQUFSLENBQVlDLFFBQVosSUFBd0IsT0FBdkM7QUFDQSxRQUFJQyxPQUFPLEdBQUcsc0JBQUFOLE9BQU8sQ0FBQ0ksR0FBUixDQUFZRyxJQUFaLHdFQUFrQkMsT0FBbEIsQ0FBMEIsTUFBMUIsRUFBa0MsRUFBbEMsTUFBeUMsV0FBdkQ7QUFDQSxRQUFJQyxPQUFPLEdBQUdULE9BQU8sQ0FBQ0ksR0FBUixDQUFZTSxJQUFaLElBQW9CLElBQWxDO0FBQ0EsUUFBSUMsTUFBTSxHQUFJLEdBQUVSLFFBQVMsS0FBSUcsT0FBUSxJQUFHRyxPQUFRLGFBQWhEOztBQUVBLFFBQUlULE9BQU8sQ0FBQ1ksT0FBUixLQUFvQkMsU0FBcEIsSUFDR2IsT0FBTyxDQUFDWSxPQUFSLENBQWdCRSxhQUFoQixLQUFrQ0QsU0FEekMsRUFDb0Q7QUFDbERYLE1BQUFBLFVBQVUsR0FBRztBQUFFLHlCQUFpQkYsT0FBTyxDQUFDWSxPQUFSLENBQWdCRTtBQUFuQyxPQUFiO0FBQ0Q7O0FBRUQsVUFBTUMsb0JBQW9CLEdBQUcsTUFBTUMsZUFBTXBCLEdBQU4sQ0FDakNlLE1BRGlDLEVBQ3pCO0FBQUVDLE1BQUFBLE9BQU8sRUFBRVYsVUFBWDtBQUF1QmUsTUFBQUEsVUFBVSxFQUFFQztBQUFuQyxLQUR5QixDQUFuQztBQUlBLFVBQU1DLGVBQWUsR0FBRyx3QkFBVUosb0JBQW9CLENBQUNLLElBQS9CLENBQXhCO0FBRUEsV0FBT25CLFFBQVEsQ0FBQ29CLEVBQVQsQ0FBWTtBQUNqQlQsTUFBQUEsT0FBTyxFQUFFO0FBQ1Asd0JBQWdCO0FBRFQsT0FEUTtBQUlqQlUsTUFBQUEsSUFBSSxFQUFFSDtBQUpXLEtBQVosQ0FBUDtBQU1ELEdBN0JIO0FBK0JEIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSVJvdXRlciB9IGZyb20gJy4uLy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgZm9ybWF0dGVyICBmcm9tICcuLi8uLi9jb21tb24vZm9ybWF0dGVyJ1xuaW1wb3J0IGF4aW9zIGZyb20gJ2F4aW9zJztcbmltcG9ydCBhZ2VudCBmcm9tICcuLi9oZWxwZXJzL3NlcnZlcl9jbGllbnQnO1xuXG5leHBvcnQgZnVuY3Rpb24gZGVmaW5lUm91dGVzKHJvdXRlcjogSVJvdXRlcikge1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvX3Byb21ldGhldXMvbWV0cmljcycsXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIGxldCByZXFIZWFkZXJzID0ge307XG4gICAgICBsZXQgcmVxUHJvdG8gPSByZXF1ZXN0LnVybC5wcm90b2NvbCB8fCAnaHR0cDonO1xuICAgICAgbGV0IHJlcUhvc3QgPSByZXF1ZXN0LnVybC5ob3N0Py5yZXBsYWNlKC86XFxkKy8sICcnKSB8fCAnMTI3LjAuMC4xJztcbiAgICAgIGxldCByZXFQb3J0ID0gcmVxdWVzdC51cmwucG9ydCB8fCA1NjAxO1xuICAgICAgbGV0IHJlcVVybCA9IGAke3JlcVByb3RvfS8vJHtyZXFIb3N0fToke3JlcVBvcnR9L2FwaS9zdGF0dXNgO1xuXG4gICAgICBpZiAocmVxdWVzdC5oZWFkZXJzICE9PSB1bmRlZmluZWRcbiAgICAgICAgICAmJiByZXF1ZXN0LmhlYWRlcnMuYXV0aG9yaXphdGlvbiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJlcUhlYWRlcnMgPSB7ICdBdXRob3JpemF0aW9uJzogcmVxdWVzdC5oZWFkZXJzLmF1dGhvcml6YXRpb24gfTtcbiAgICAgIH1cblxuICAgICAgY29uc3Qga2liYW5hSW50ZXJuYWxTdGF0dXMgPSBhd2FpdCBheGlvcy5nZXQoXG4gICAgICAgIHJlcVVybCwgeyBoZWFkZXJzOiByZXFIZWFkZXJzLCBodHRwc0FnZW50OiBhZ2VudCB9XG4gICAgICApO1xuICAgICAgXG4gICAgICBjb25zdCBwcm9tZXRoZXVzU3RhdHMgPSBmb3JtYXR0ZXIoa2liYW5hSW50ZXJuYWxTdGF0dXMuZGF0YSk7XG5cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ3RleHQvcGxhaW4nLFxuICAgICAgICB9LFxuICAgICAgICBib2R5OiBwcm9tZXRoZXVzU3RhdHMsXG4gICAgICB9KTtcbiAgICB9XG4gICk7XG59XG4iXX0=